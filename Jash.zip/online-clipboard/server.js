const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static("public"));

let clipboardStore = {}; // temporary memory store

// Generate 6-digit code
function generateCode() {
    return Math.floor(100000 + Math.random() * 900000).toString();
}

// Save clipboard data
app.post("/save", (req, res) => {
    const { content } = req.body;
    if (!content) {
        return res.status(400).json({ error: "No content provided" });
    }

    const code = generateCode();
    clipboardStore[code] = content;

    // Auto-delete after 10 minutes
    setTimeout(() => {
        delete clipboardStore[code];
    }, 10 * 60 * 1000);

    res.json({ code });
});

// Get clipboard data
app.get("/get/:code", (req, res) => {
    const code = req.params.code;
    const content = clipboardStore[code];

    if (!content) {
        return res.status(404).json({ error: "Code not found or expired" });
    }

    res.json({ content });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
