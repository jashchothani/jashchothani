const socket = io()
const video = document.getElementById("video")

let peer
let room = ""

function generateCode(){
    return Math.random().toString(36).substring(2,8).toUpperCase()
}

async function createRoom(){

    room = generateCode()

    document.getElementById("roomCode").innerText = room

    socket.emit("join", room)

    const stream = await navigator.mediaDevices.getDisplayMedia({video:true})

    video.srcObject = stream

    peer = new RTCPeerConnection()

    stream.getTracks().forEach(track=>{
        peer.addTrack(track,stream)
    })

    peer.onicecandidate = e=>{
        if(e.candidate){
            socket.emit("candidate",{room,candidate:e.candidate})
        }
    }

    socket.on("viewer", async ()=>{

        const offer = await peer.createOffer()

        await peer.setLocalDescription(offer)

        socket.emit("offer",{room,offer})

    })

}

function joinRoom(){

    room = document.getElementById("roomInput").value

    socket.emit("join", room)

}